import dotenv from "dotenv"

dotenv.config()

export const application={
    port:process.env.PORT
}